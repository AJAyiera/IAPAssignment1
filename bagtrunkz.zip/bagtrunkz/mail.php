<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require './PHPMailer/src/Exception.php';
require './PHPMailer/src/PHPMailer.php';
require './PHPMailer/src/SMTP.php';

if (isset($_POST['sendbtn'])) {
    $name = htmlentities($_POST['name']);
    $email = htmlentities($_POST['email']);
    $password = htmlentities($_POST['password']);

    $message = "Thank you " . $name . " for making an account with Bag Trunkz";

    $mail = new PHPMailer(true);

    try {
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'strathtaskapp@gmail.com';
        $mail->Password = 'strath.task123';
        $mail->Port = 587; 
        $mail->SMTPSecure = 'tls'; 
        $mail->isHTML(true);
        $mail->setFrom($email, $name);
        $mail->addAddress('strathtaskapp@gmail.com');
        $mail->Subject = "Registration";
        $mail->Body = $message;

        if ($mail->send()) {
            echo 'Message has been sent';
        } else {
            echo 'Message could not be sent. Mailer Error: ' . $mail->ErrorInfo;
        }
    } catch (Exception $e) {
        echo 'Message could not be sent. Mailer Error: ' . $mail->ErrorInfo;
    }
}
?>